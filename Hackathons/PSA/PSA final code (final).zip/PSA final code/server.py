from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import random

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///logistics.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'  # For flash messages
db = SQLAlchemy(app)

# Database Models

class Admin(db.Model):
    __tablename__ = 'admin'
    keyID = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    employee_id = db.Column(db.String(50), nullable=True, unique=True)
    password = db.Column(db.String(100), nullable=False)
    user_type = db.Column(db.String(100), nullable=True)
    gender = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)

class COORUser(db.Model):
    __tablename__ = 'coor_user'
    keyID = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    name = db.Column(db.String(100), nullable=False)
    business_name = db.Column(db.String(100))  # Optional
    contact_number = db.Column(db.String(20))
    email = db.Column(db.String(100), nullable=False, unique=True)
    telegram_chat_id = db.Column(db.String(50), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    

class Container(db.Model):
    __tablename__ = 'container'
    containerID = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    date_completed = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    coor_user_id = db.Column(db.Integer, db.ForeignKey('coor_user.keyID'), nullable=False)
    dimensions = db.Column(db.String(50))
    tags = db.Column(db.String(200))  # Stores tags as a comma-separated string
    description = db.Column(db.Text)
    origin_location = db.Column(db.String(100))
    destination_location = db.Column(db.String(100))
    date_of_departure = db.Column(db.DateTime, nullable=True)
    date_of_arrival = db.Column(db.DateTime, nullable=True)
    completed = db.Column(db.String(20), nullable=False, default="Unmatched")  # Changed to String
    flexidate_tolerance = db.Column(db.Integer, nullable=True)  # Tolerance in days
    constituent_cargo = db.relationship('Cargo', backref='container', lazy=True)

class Cargo(db.Model):
    __tablename__ = 'cargo'
    cargoID = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    date_completed = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    coor_user_id = db.Column(db.Integer, db.ForeignKey('coor_user.keyID'), nullable=False)
    dimensions = db.Column(db.String(50))
    weight = db.Column(db.String(50))
    tags = db.Column(db.String(200))  # Stores tags as a comma-separated string
    description = db.Column(db.Text)
    origin_location = db.Column(db.String(100))
    destination_location = db.Column(db.String(100))
    date_of_departure = db.Column(db.DateTime, nullable=True)
    date_of_arrival = db.Column(db.DateTime, nullable=True)
    completed = db.Column(db.String(20), nullable=False, default="Unmatched")  # Changed to String
    flexidate_tolerance = db.Column(db.Integer, nullable=True)  # Tolerance in days
    container_id = db.Column(db.Integer, db.ForeignKey('container.containerID'), nullable=True)  # Nullable to allow for unmatched cargo

class Dispute(db.Model):
    __tablename__ = 'dispute'
    disputeID = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    date_completed = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), nullable=False)
    dispute_plaintiff = db.Column(db.Integer, db.ForeignKey('coor_user.keyID'), nullable=False)
    involved_users = db.Column(db.String(200))  # Comma-separated COOR IDs
    description = db.Column(db.Text, nullable=False)
    container_id = db.Column(db.Integer, db.ForeignKey('container.containerID'), nullable=True)  # Add this column
    cargoID = db.Column(db.Integer, primary_key=True)
    coor_user_id = db.Column(db.Integer, db.ForeignKey('coor_user.keyID'), nullable=False)



# Route for home page
@app.route('/')
def home():
    return render_template('index.html')

# Route for Cargo Dashboard
@app.route('/User login page')
def User_login_page():
    return render_template('User login page.html')

# Route for Cargo Dashboard
@app.route('/PSA login page')
def PSA_login_page():
    return render_template('PSA login page.html')
# Route for Cargo Dashboard

@app.route('/Registration page')
def Registration_page():
    return render_template('Registration page.html')

@app.route('/PSA Dash Board')
def PSA_Dash_Board():
    return render_template('PSA Dash Board.html')

@app.route('/PSA_active_container')
def PSA_active_container():
    return render_template('PSA Active Container.html')

@app.route('/PSA_Unmatched_container')
def PSA_Unmatched_container():
    return render_template('PSA Unmatched Container.html')

@app.route('/PSA_History_container')
def PSA_History_container():
    return render_template('PSA History Container.html')

@app.route('/PSA_active_cargo')
def PSA_active_cargo():
    return render_template('PSA Active Cargo.html')

@app.route('/PSA_Unmatched_cargo')
def PSA_Unmatched_cargo():
    return render_template('PSA Unmatched Cargo.html')

@app.route('/PSA_Histroy_cargo')
def PSA_History_cargo():
    return render_template('PSA History Cargo.html')

@app.route('/Cargo_DashBoard')
def Cargo_DashBoard():
    return render_template('Cargo DashBoard.html')

@app.route('/Cargo_Booking')
def Cargo_Booking():
    return render_template('Cargo Booking.html')

@app.route('/Cargo Info')
def Cargo_Info():
    return render_template('Cargo Info.html')

@app.route('/Cargo Disputes')
def Cargo_Disputes():
    return render_template('Cargo Disputes.html')


@app.route('/login', methods=['POST'])
def User_login():
    username = request.form['username']
    password = request.form['password']
    print(username, password)
    user_type = 'Container' if request.form.get('user_type') else 'Cargo'
    print(user_type)

    # Find the user in the Admin database
    admin = Admin.query.filter_by(username=username, password=password).first()

    if admin:
        # Store session details
        session['user_id'] = admin.keyID  # Corrected to use the instance's actual value
        session['username'] = admin.username  # Corrected to use the instance's actual value
        session['user_type'] = user_type

        # Redirect based on user type
        if user_type == 'Cargo':
            return redirect(url_for('Cargo_DashBoard'))
        elif user_type == 'Container':
            return redirect(url_for('PSA_login_page'))
    else:
        flash('Invalid username or password!', 'danger')
        print('Invalid username or password!', 'danger')
        return redirect(url_for('User_login_page'))
    
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('user_type', None)
    flash('You have been logged out.')
    return redirect(url_for('login'))

@app.route('/PSAlogin', methods=['POST'])
def PSA_login():
    # Retrieve form data
    employee_id = request.form['employee_id']
    username = request.form['username']
    password = request.form['password']

    # Debug print statements to verify inputs
    print(f"Username: {username}, Password: {password}, Employee ID: {employee_id}")

    # Query the Admin table to find the user by employee_id, username, and password
    admin = Admin.query.filter_by(employee_id=employee_id, username=username, password=password).first()

    # Check if the user exists
    if admin:
        # Check if the user type is 'PSA'
        if admin.user_type == 'PSA':
            flash('Login successful!', 'success')
            return redirect(url_for('PSA_Dash_Board'))  # Redirect to PSA dashboard
        else:
            # If user exists but not of type 'PSA', show error
            flash('You are not authorized to access this page!', 'danger')
            return redirect(url_for('User_login_page'))
    else:
        # If no matching user found, show error
        flash('Invalid username, password, or employee ID!', 'danger')
        print('Invalid username, password, or employee ID!', 'danger')
        return redirect(url_for('User_login_page'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Retrieve form data
        full_name = request.form['full_name']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        user_type = 'Container' if request.form.get('user_type') else 'Cargo'
        gender = request.form['gender']

        # Password validation
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('register'))

        # Create a new Admin object
        new_admin = Admin(
            name=full_name,
            username=username,
            password=password,
            user_type=user_type,
            gender=gender,
            email=email
        )

        try:
            # Add the new admin to the database
            db.session.add(new_admin)
            db.session.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('User_login_page'))  # Redirect to a home page or login page
        except Exception as e:
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/get-all-containers', methods=['GET'])
def get_all_containers():
    # Filter containers that are in transit
    containers = Container.query.filter_by(status="In Transit").all()
    container_list = []

    for container in containers:
        container_list.append({
            'containerID': container.containerID,
            'name': container.name,
            'quantity': 'N/A',  # Adjust according to your model logic
            'date_created': container.date_created.strftime('%Y-%m-%d'),
            'date_completed': container.date_completed.strftime('%Y-%m-%d') if container.date_completed else None,
            'date_of_departure': container.date_of_departure.strftime('%Y-%m-%d') if container.date_of_departure else None,
            'date_of_arrival': container.date_of_arrival.strftime('%Y-%m-%d') if container.date_of_arrival else None,
            'status': container.status,
            'origin_location': container.origin_location,
            'destination_location': container.destination_location,
            'description': container.description,
        })

    return jsonify({'containers': container_list})

@app.route('/get-all-containers-Delivered', methods=['GET'])
def get_all_containers_Delivered():
    # Filter containers that are in transit
    containers = Container.query.filter_by(status="Delivered").all()
    container_list = []

    for container in containers:
        container_list.append({
            'containerID': container.containerID,
            'name': container.name,
            'quantity': 'N/A',  # Adjust according to your model logic
            'date_created': container.date_created.strftime('%Y-%m-%d'),
            'date_completed': container.date_completed.strftime('%Y-%m-%d') if container.date_completed else None,
            'date_of_departure': container.date_of_departure.strftime('%Y-%m-%d') if container.date_of_departure else None,
            'date_of_arrival': container.date_of_arrival.strftime('%Y-%m-%d') if container.date_of_arrival else None,
            'status': container.status,
            'origin_location': container.origin_location,
            'destination_location': container.destination_location,
            'description': container.description,
        })

    return jsonify({'containers': container_list})

@app.route('/get-all-containers-Pending', methods=['GET'])
def get_all_containers_Pending():
    # Filter containers that are in transit
    containers = Container.query.filter_by(status="Pending").all()
    container_list = []

    for container in containers:
        container_list.append({
            'containerID': container.containerID,
            'name': container.name,
            'quantity': 'N/A',  # Adjust according to your model logic
            'date_created': container.date_created.strftime('%Y-%m-%d'),
            'date_completed': container.date_completed.strftime('%Y-%m-%d') if container.date_completed else None,
            'date_of_departure': container.date_of_departure.strftime('%Y-%m-%d') if container.date_of_departure else None,
            'date_of_arrival': container.date_of_arrival.strftime('%Y-%m-%d') if container.date_of_arrival else None,
            'status': container.status,
            'origin_location': container.origin_location,
            'destination_location': container.destination_location,
            'description': container.description,
        })

    return jsonify({'containers': container_list})


@app.route('/get-cargo-details/<int:container_id>', methods=['GET'])
def get_cargo_details(container_id):
    # Fetch cargo related to the specific container ID
    cargo_items = Cargo.query.filter_by(container_id=container_id).all()
    print(cargo_items)

    # Prepare the cargo data for response
    cargo_list = []
    
    for cargo in cargo_items:
        cargo_list.append({
            'product_name': cargo.name,
            'product_id': cargo.cargoID,
            'quantity': f"{random.randint(500, 1000)} kg",  # Adjust if actual quantity data exists
            'dimension': cargo.dimensions,
            'tags': cargo.tags,
            'flexidate_tolerance': cargo.flexidate_tolerance
        })
    print(cargo_list)

    # Return the cargo data as JSON
    return jsonify({'cargo': cargo_list})


@app.route('/get-complaints-details/<int:container_id>', methods=['GET'])
def get_complaints_details(container_id):
    # Fetch complaints related to the specific container ID
    complaints_items = Dispute.query.filter_by(container_id=container_id).all()

    # Prepare the complaints data for response
    complaints_list = []
    
    for complaint in complaints_items:
        complaints_list.append({
            'complaint_id': complaint.disputeID,
            'description': complaint.description,
            'date': complaint.date_created.strftime('%Y-%m-%d')  # Assuming date_created field exists
        })

    # Return the complaints data as JSON
    return jsonify({'complaints': complaints_list})

@app.route('/get-all-cargo', methods=['GET'])
def get_all_cargo():
    # Fetch only the cargo items that are 'In Progress'
    cargo_items = Cargo.query.filter_by(status='In Progress').all()

    # Prepare the cargo data for response
    cargo_list = []
    for cargo in cargo_items:
        cargo_list.append({
            'cargoID': cargo.cargoID,
            'date_created': cargo.date_created.strftime('%Y-%m-%d'),
            'date_completed': cargo.date_completed.strftime('%Y-%m-%d') if cargo.date_completed else None,
            'status': cargo.status,
            'name': cargo.name,
            'dimensions': cargo.dimensions,
            'tags': cargo.tags,
            'additional_description': cargo.description,
            'origin_location': cargo.origin_location,
            'destination_location': cargo.destination_location,
            'date_of_departure': cargo.date_of_departure.strftime('%Y-%m-%d') if cargo.date_of_departure else None,
            'date_of_arrival': cargo.date_of_arrival.strftime('%Y-%m-%d') if cargo.date_of_arrival else None,
            'completed': 'Yes' if cargo.completed else 'No',
            'flexidate_tolerance': cargo.flexidate_tolerance,
            'assigned_container': cargo.container_id  # Assuming container_id is a foreign key
        })

    # Return the filtered cargo data as JSON
    return jsonify({'cargo': cargo_list})


@app.route('/get-all-cargo-Delivered', methods=['GET'])
def get_all_cargo_Delivered():
    # Fetch only the cargo items that are 'In Progress'
    cargo_items = Cargo.query.filter_by(status='Completed').all()
    # Prepare the cargo data for response
    cargo_list = []
    for cargo in cargo_items:
        cargo_list.append({
            'cargoID': cargo.cargoID,
            'date_created': cargo.date_created.strftime('%Y-%m-%d'),
            'date_completed': cargo.date_completed.strftime('%Y-%m-%d') if cargo.date_completed else None,
            'status': cargo.status,
            'name': cargo.name,
            'dimensions': cargo.dimensions,
            'tags': cargo.tags,
            'additional_description': cargo.description,
            'origin_location': cargo.origin_location,
            'destination_location': cargo.destination_location,
            'date_of_departure': cargo.date_of_departure.strftime('%Y-%m-%d') if cargo.date_of_departure else None,
            'date_of_arrival': cargo.date_of_arrival.strftime('%Y-%m-%d') if cargo.date_of_arrival else None,
            'completed': 'Yes' if cargo.completed else 'No',
            'flexidate_tolerance': cargo.flexidate_tolerance,
            'assigned_container': cargo.container_id  # Assuming container_id is a foreign key
        })

    # Return the filtered cargo data as JSON
    return jsonify({'cargo': cargo_list})

@app.route('/get-all-cargo-pending', methods=['GET'])
def get_all_cargo_pending():
    # Fetch only the cargo items that are 'In Progress'
    cargo_items = Cargo.query.filter_by(status='Pending').all()
    # Prepare the cargo data for response
    cargo_list = []
    for cargo in cargo_items:
        cargo_list.append({
            'cargoID': cargo.cargoID,
            'date_created': cargo.date_created.strftime('%Y-%m-%d'),
            'date_completed': cargo.date_completed.strftime('%Y-%m-%d') if cargo.date_completed else None,
            'status': cargo.status,
            'name': cargo.name,
            'dimensions': cargo.dimensions,
            'tags': cargo.tags,
            'additional_description': cargo.description,
            'origin_location': cargo.origin_location,
            'destination_location': cargo.destination_location,
            'date_of_departure': cargo.date_of_departure.strftime('%Y-%m-%d') if cargo.date_of_departure else None,
            'date_of_arrival': cargo.date_of_arrival.strftime('%Y-%m-%d') if cargo.date_of_arrival else None,
            'completed': 'Yes' if cargo.completed else 'No',
            'flexidate_tolerance': cargo.flexidate_tolerance,
            'assigned_container': cargo.container_id  # Assuming container_id is a foreign key
        })

    # Return the filtered cargo data as JSON
    return jsonify({'cargo': cargo_list})

@app.route('/submit-cargo', methods=['POST'])
def submit_cargo():
    # Ensure that the user is logged in
    if 'user_id' not in session:
        return jsonify({'message': 'User is not logged in.'}), 403  # Unauthorized access

    data = request.json

    try:
        # Get the user_id from the session
        user_id = session['user_id']
        
        # Retrieve the Admin user based on user_id
        admin_user = Admin.query.filter_by(keyID=user_id).first()
        
        if not admin_user:
            return jsonify({'message': 'Admin user not found.'}), 404
        
        # Check if user exists in COORUser based on the provided email or admin's keyID
        existing_user = COORUser.query.filter_by(email=data.get('business_email')).first()

        if existing_user:
            # User already exists, use their keyID
            coor_user_id = existing_user.keyID
        else:
            # User doesn't exist, create a new COORUser and assign the same keyID from Admin user
            new_user = COORUser(
                keyID=admin_user.keyID,  # Assign the same keyID from Admin user
                date_created=datetime.utcnow(),
                name=admin_user.name,  # Autofill from Admin database
                business_name=data.get('business_name', ''),
                contact_number=data.get('phone_number'),
                email=data.get('business_email'),
                telegram_chat_id=data.get('chat_id'),  # If applicable
                is_active=True  # Assuming all newly created users are active
            )
            db.session.add(new_user)
            db.session.commit()

            # After committing, the new user's keyID will be the same as Admin's
            coor_user_id = new_user.keyID

        # Create new cargo instance with received data and coor_user_id
        new_cargo = Cargo(
            date_created=datetime.utcnow(),
            status='In Progress',  # Assuming all newly created cargo starts as 'In Progress'
            name=data.get('name'),
            coor_user_id=coor_user_id,  # Assign the user ID from COORUser
            dimensions=f"{data['dimensions']['length']}x{data['dimensions']['width']}x{data['dimensions']['height']}",
            weight=data.get('weight'),
            tags=', '.join(data.get('tags', [])),  # Join tags array into a comma-separated string
            description=data.get('additional_comments', ''),
            origin_location=data.get('origin'),
            destination_location=data.get('destination'),
            date_of_departure=datetime.strptime(data.get('send_off_date'), '%Y-%m-%d') if data.get('send_off_date') else None,
            date_of_arrival=datetime.strptime(data.get('arrival_date'), '%Y-%m-%d') if data.get('arrival_date') else None,
            completed='Unmatched',  # Default to 'No'
            flexidate_tolerance=data.get('flexidate_tolerance', 0)  # Default tolerance to 0
        )

        # Save the new cargo to the database
        db.session.add(new_cargo)
        db.session.commit()

        return jsonify({'message': 'Cargo and user data saved successfully!'}), 200

    except Exception as e:
        db.session.rollback()
        print(f"Error saving cargo data: {e}")
        return jsonify({'message': 'Failed to save cargo and user data.'}), 500

@app.route('/get-user-cargo', methods=['GET'])
def get_user_cargo():
    if 'user_id' not in session:
        return jsonify({'message': 'User is not logged in.'}), 403  # Unauthorized access

    user_id = session['user_id']

    try:
        # Fetching all cargo entries that match the logged-in user's keyID in the COORUser table
        cargo_entries = Cargo.query.join(COORUser, COORUser.keyID == Cargo.coor_user_id).filter(COORUser.keyID == user_id).all()
        cargo_list = [{
            'cargoID': cargo.cargoID,
            'date_created': cargo.date_created.strftime('%Y-%m-%d'),
            'date_completed': cargo.date_completed.strftime('%Y-%m-%d') if cargo.date_completed else 'N/A',
            'status': cargo.status,
            'dimensions': cargo.dimensions,
            'weight': cargo.weight,
            'tags': cargo.tags,
            'description': cargo.description,
            'origin_location': cargo.origin_location,
            'destination_location': cargo.destination_location,
            'date_of_departure': cargo.date_of_departure.strftime('%Y-%m-%d') if cargo.date_of_departure else 'N/A',
            'date_of_arrival': cargo.date_of_arrival.strftime('%Y-%m-%d') if cargo.date_of_arrival else 'N/A',
            'flexidate_tolerance': cargo.flexidate_tolerance
        } for cargo in cargo_entries]

        return jsonify(cargo_list), 200

    except Exception as e:
        print(f"Error fetching cargo data: {e}")
        return jsonify({'message': 'Failed to fetch cargo data.'}), 500
    
@app.route('/delete-cargo', methods=['POST'])
def delete_cargo():
    data = request.get_json()
    cargo_ids = data.get('cargoIDs', [])
    print("Received cargo IDs for deletion:", cargo_ids)  # Print received cargo IDs

    response = {'status': 'success'}
    if not cargo_ids:
        print("No cargo IDs provided for deletion.")
        response['status'] = 'error'
        response['message'] = 'No cargo IDs provided'
        return jsonify(response)

    try:
        query = Cargo.query.filter(Cargo.cargoID.in_(cargo_ids))
        print(f"Prepared to execute delete query: {str(query)}")  # Print the query
        deleted_count = query.delete(synchronize_session=False)
        db.session.commit()
        print(f"Number of cargo entries deleted: {deleted_count}")  # Print number of deletions
        if deleted_count == 0:
            response['status'] = 'warning'
            response['message'] = 'No entries found with provided IDs'
    except Exception as e:
        db.session.rollback()
        response['status'] = 'error'
        response['message'] = str(e)
        print(f"Failed to delete cargo: {e}")  # Print error message
    finally:
        db.session.close()

    return jsonify(response)
    
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create tables if they don't exist
    # with app.app_context():
    #     populate_database()
    app.run(debug=True)
    
    
    